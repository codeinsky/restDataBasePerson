package dataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class connection {
public static Connection createConnection() {
	String url = "jdbc:derby://localhost:1527/restDataBase;";
	Connection con = null; 
	try {
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		con = DriverManager.getConnection(url);
		System.out.println("connection done");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return con; 
}

public static void createPerson(String name , int age ) {
	Connection connection = createConnection();
	String sql="Insert into REST(NAME , AGE) values('" + name + "' ," + age +")" ;
	try {
	Statement st = connection.createStatement();
	st.executeUpdate(sql);
		connection.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

public static int getPersonAge(String name) {
	int age=0;
	Connection connection = createConnection();
	String sql ="SELECT AGE FROM REST WHERE NAME='" + name  +"'" ;
	try {
	Statement st = connection.createStatement();
	ResultSet rs = st.executeQuery(sql);
	if (rs.next())
			age=rs.getInt("AGE");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	return age; 
}
public static void main(String[] args) {
	createPerson("peter" , 50 );
	System.out.println(getPersonAge ("peter"));
}

}
